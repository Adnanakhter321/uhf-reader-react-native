import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, TouchableOpacity, Alert, Button, Image, Modal, NativeEventEmitter, Pressable, ScrollView, StyleSheet, Text, TextInput, ToastAndroid, View } from "react-native";
import C72RFIDScanner from "uhf-reader-react-native";
import { Table, Row, Rows } from 'react-native-table-component';
import { Switch } from "react-native-gesture-handler";
import { getData, showAndroidToast, storeData } from "../utils/Constants";


const Home = () => {
  const [isReading, setIsReading] = React.useState();
  const [powerState, setPowerState] = React.useState('');
  const eventEmitter = new NativeEventEmitter();
  const [power, setPower] = React.useState(0)
  const [spinner, setSpinner] = React.useState(true)
  const [tableData, setTableData] = React.useState([])
  const [modalVisible, setModalVisible] = useState(false);
  const [modalVisible2, setModalVisible2] = useState(false);
  const [selectedItem, setSelectedItem] = useState({});
  const [batcherVal, setBatcherVal] = useState("");

  const [isEnabled, setIsEnabled] = useState(false);

  // const total = useMemo(() => tags.length, [tags])
  const showAlert = (title, data) => {
    Alert.alert(
      title,
      data,
      [
        { text: 'OK', onPress: () => console.log('OK Pressed') },
      ],
      { cancelable: false },
    );
  }

  const powerListener = (data) => {
    setPowerState(data);
  }
  const renderImage = (image: any) => <Image source={image} style={{ width: 50, height: 50, resizeMode: 'contain', alignSelf: 'center' }} />
  const tagListener = async (data) => {
    try{
      // Given timestamp in seconds
      const timestamp = new Date().getTime();
      // console.log(new Date().getTime())
      // Convert the timestamp to milliseconds and create a Date object
      const date = new Date(timestamp);

      // Manually format the date and time
      const day = String(date.getDate()).padStart(2, '0'); // Ensure 2-digit day
      const monthNames = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
      ];
      const month = monthNames[date.getMonth()];
      const year = date.getFullYear();

      let hours = date.getHours();
      const minutes = String(date.getMinutes()).padStart(2, '0'); // Ensure 2-digit minutes
      const seconds = String(date.getSeconds()).padStart(2, '0'); // Ensure 2-digit seconds

      // Convert to 12-hour format and determine AM/PM
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12 || 12; // Convert 0 to 12 for 12-hour format

      // Construct the formatted string
      const formattedDate = `${day}-${month}-${year}${"\n\n"}${String(hours).padStart(2, '0')}:${minutes}:${seconds} ${ampm}`;
      const resP = await getData("tagItems");
      const parseData = Array.isArray(JSON.parse(resP))?JSON.parse(resP):[]
      const filterItem = parseData? parseData.filter((el:any)=>el[2]===data[0]):[]
      setTableData((old) => {
        const updatedOld = Array.isArray(old) ? old : []; // Ensure `old` is an array
        return [
          ...updatedOld,
          [
            Array.isArray(filterItem[0])?filterItem?.[0]?.[0]:"",
            "WareHouse-1",
            data[0],
            formattedDate,
          ],
        ] as any;
      });
      // await storeData("tagItems", JSON.stringify([...parseData,[Array.isArray(filterItem?.[0])?filterItem?.[0]?.[0]:"", 'WareHouse-1', data[0], formattedDate]]));
    }
    catch(er:any){
      showAndroidToast(er?.message)
    }
  }
  //05-September-2024 06:36:02 PM
  const [scanVar, setScanvar] = useState('auto')
  const [start, setStart] = useState(false)
  React.useEffect(() => {
    const subscription = eventEmitter.addListener('onHardwareKeyPress', async (event) => {
      // there will listen hardware events e.g scan button
      if (start !== true) {
        if (scanVar == 'singlescan') {
          // scanSingleTag()
        }
        else {
          setStart(true)
          C72RFIDScanner.startReadingTags(function success(message) {
            setIsReading(message);
          })
        }
      }
      else {
        setStart(false)
        C72RFIDScanner.stopReadingTags(function success(message) {
          setIsReading(false);
        });
      }
    });
    return () => {
      subscription.remove();
    };
  }, [scanVar, start])
  React.useEffect(() => {
    (async () => {
      try {
        const scanner = C72RFIDScanner;
        const result = await scanner.initializeUHF()
        setIsEnabled(true)
        setTimeout(() => setSpinner(false), 2000)
        setPowerState(result)
        scanner.tagListener(tagListener);
        scanner.powerListener(powerListener);
        let power = await C72RFIDScanner.readPower();
        setPower(Number(power))

      } catch (er) {
        Alert.alert(er?.message)
      }
    })()
    return () => {
      C72RFIDScanner.clearTags();
      C72RFIDScanner.deinitializeUHF();
      C72RFIDScanner.releaseSoundPool()
    }
  }, []);
  const readPower = async () => {
    try {
      let result = await C72RFIDScanner.readPower();
      showAlert('SUCCESS', `The result is ${result}`);
      console.log(result);
    } catch (error) {
      showAlert('FAILED', error.message);
    }
  }
  const state = {
    tableHead: ['Batcher Name', 'Location', 'Tag', 'Date'],
    tableData: tableData,
  }
  const toggleSwitch = async () => {
    try {
      if (!isEnabled) {
        const scanner = C72RFIDScanner;
        const result = await scanner.initializeUHF()
        setIsEnabled(previousState => !previousState);
      }
      else {
        C72RFIDScanner.clearTags();
        await C72RFIDScanner.deinitializeUHF();
        C72RFIDScanner.releaseSoundPool()
        setIsEnabled(previousState => !previousState);
      }
    } catch (er: any) {
      ToastAndroid.show(er?.message, ToastAndroid.SHORT);
    }
  }
  // useEffect(() => {
  //   (async () => {
  //       if(modalVisible2 === false){
  //       const myData = await getData("tagItems")
  //       const newData = JSON.parse(myData).map((el: any) => [el.name, el?.location, el?.tag, el?.date])
  //       setTableData(newData)
  //     }
  //     })();
  // }, [modalVisible2])
  let myTimeout:any;
  useEffect(() => {
    clearTimeout(myTimeout)
     myTimeout = setTimeout(async () => {
       if(Array.isArray(tableData) && tableData?.length > 0){
        await storeData("tagItems", JSON.stringify(tableData));
        showAndroidToast("data synced")
       }
    }, 100)
  }, [tableData])
  useEffect(() => {
    (async () => {
      const myData = await getData("tagItems")
      setTableData(JSON.parse(myData))
    })();
  }, [])
  return (
    <ScrollView style={{ flex: 1, backgroundColor: 'white' }}>
      <View>
        <Text style={{ textAlign: 'center', color: '#192f4b', fontSize: 30, marginBottom: 20, }}>Smart Asset</Text>
        <View style={{ flexDirection: 'row', alignSelf: 'center' }}>
          <TouchableOpacity onPress={async () => {
            try {
              // await storeData("tagItems", JSON.stringify([]))
              C72RFIDScanner.clearTags();
              setTableData([])
            } catch (er: any) {
              showAndroidToast(er.message)
            }
          }} style={{ width: 120, height: 35, backgroundColor: "#192f4b", borderRadius: 3, alignItems: 'center', justifyContent: 'center', alignSelf: 'center' }}>
            <Text style={{ color: 'white' }}>CLEAR TAGS</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={async () => {
            setModalVisible(!modalVisible)
          }} style={{ width: 120, marginLeft: 10, height: 35, backgroundColor: "#192f4b", borderRadius: 3, alignItems: 'center', justifyContent: 'center', alignSelf: 'center' }}>
            <Text style={{ color: 'white' }}>SETTINGS</Text>
          </TouchableOpacity>
        </View>
        {start && <Text style={{ color: 'black', fontSize: 15, textAlign: 'center', marginTop: 14 }}>Scanning multiple...</Text>}
      </View>
      <View style={styles.container}>
        <Table borderStyle={{ borderWidth: 0.1, borderColor: 'gray' }}>
          <Row data={state.tableHead} style={styles.head} textStyle={styles.text1} />
          {/* <Rows data={state.tableData} textStyle={styles.text2}/> */}
          <ScrollView style={styles.dataWrapper}>
            <Table borderStyle={{ borderWidth: 0.5, borderColor: 'gray' }}>
              {
                tableData?.map((rowData, index) => {
                  return ((
                    <TouchableOpacity onPress={() => {
                      setModalVisible2(!modalVisible2)
                      setSelectedItem(rowData)
                    }}>
                      <Row
                        key={index}
                        data={rowData}
                        textStyle={styles.text2}
                        borderStyle={{ borderWidth: 1, borderColor: 'gray' }}
                        widthArr={state.widthArr}
                      />
                    </TouchableOpacity>
                  ))
                })
              }
            </Table>
          </ScrollView>
        </Table>
      </View>
      {spinner && <View style={{ position: 'absolute', width: '100%', height: '100%', backgroundColor: '#ffffff90', zIndex: 2 }}>
        <ActivityIndicator style={{ position: 'absolute', width: '100%', height: '100%' }} color={'black'} />
        <View style={{ marginTop: 10, top: '47%', alignSelf: 'center' }}><Text style={{ color: 'black', top: 25, fontSize: 18, fontFamily: "" }}>Initializing</Text></View>
      </View>}
      {/* Modal 1 */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(!modalVisible);
        }}>
        <View style={styles.centeredView}>

          <Text
            onPress={() => {
              setModalVisible(!modalVisible)
            }}
            style={{ color: 'black', marginTop: 10, fontSize: 15, alignSelf: 'flex-end', marginRight: 20 }}>
            Close
          </Text>

          <Text style={{ color: 'black', marginTop: 20, fontSize: 25 }}>Settings</Text>

          <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 40 }}>
            <Text style={{ color: 'black', fontSize: 18 }}>UHF Reader Initialization</Text>
            <Switch
              trackColor={{ false: '#767577', true: '#81b0ff' }}
              thumbColor={isEnabled ? '#f5dd4b' : '#f4f3f4'}
              ios_backgroundColor="#3e3e3e"
              onValueChange={toggleSwitch}
              style={{ marginLeft: 20 }}
              value={isEnabled}
            />
          </View>

          <View style={{ marginVertical: 20, flexDirection: 'row', alignItems: 'center', marginTop: 30 }}>
            <View style={{ alignSelf: 'center' }}>
              <Button
                color={'#192f4b'}
                onPress={async () => {
                  try {
                    const scanner = C72RFIDScanner;
                    const result = await scanner.changePower(power);
                    showAndroidToast('Success');
                  } catch (er: any) {
                    showAndroidToast(er.message);
                  }
                }}
                title="Change Power"
              />
            </View>
            <TextInput
              style={{ width: 150, marginLeft: 10, height: 40, borderWidth: 1, borderColor: 'black', borderRadius: 30, paddingHorizontal: 10 }}
              value={String(power)}
              onChangeText={(val) => setPower(Number(val))}
              keyboardType="number-pad"
              maxLength={2}
            />
          </View>

          {/* <View style={{ height: 0.7, backgroundColor: 'black', width: "90%" }} /> */}
        </View>
      </Modal>

      {/* Modal 2 */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible2}
        onRequestClose={() => {
          setModalVisible2(!modalVisible2);
        }}>
        <View style={[styles.centeredView, { alignItems: 'flex-start' }]}>
          <Text
            onPress={() => {
              setModalVisible2(!modalVisible2)
            }}
            style={{ color: 'black', marginTop: 10, fontSize: 15, alignSelf: 'flex-end', marginRight: 20 }}>
            Close
          </Text>

          <View style={{ alignSelf: 'center' }}>
            <Text style={{ color: 'black', marginTop: 20, fontSize: 25, textAlign: 'center' }}>EDIT TAG NAME</Text>
          </View>
          {/* center view */}
          <View style={{ paddingHorizontal: 20, width: '100%' }}>


            <View style={{ marginTop: 40 }}>
              <Text style={{ color: 'black', fontSize: 18, marginBottom: 5 }}>TAG ID: </Text>
              <TextInput
                style={{ height: 45, borderWidth: 1, borderColor: 'black', borderRadius: 10, paddingHorizontal: 10, color: 'black' }}
                value={selectedItem[2] as String}
                editable={false}
              />
            </View>

            <View style={{ marginTop: 20 }}>
              <Text style={{ color: 'black', fontSize: 18, marginBottom: 5 }}>BATCHER NAME: </Text>
              <TextInput
                style={{ height: 45, borderWidth: 1, borderColor: 'black', borderRadius: 10, paddingHorizontal: 10, color: 'black' }}
                // value={selectedItem[2] as String}
                placeholder="Enter Batcher Name"
                onChangeText={(val) => setBatcherVal(val)}
              />
            </View>

            <View style={{ marginVertical: 20, flexDirection: 'row', alignItems: 'center', marginTop: 30, alignSelf: "center" }}>
              <TouchableOpacity
                onPress={async () => {
                  if (batcherVal.trim() === "") {
                    showAndroidToast("Enter Batcher Value First..");
                    return;
                  }
                  const item = [batcherVal, selectedItem[1], selectedItem[2], selectedItem[3]];

                  try {
                    
                    const parsedData = JSON.parse(JSON.stringify(tableData)); // Parse it or initialize an empty array

                    // Find the index of an item with the same `tag`
                    const existingIndex = parsedData.findIndex((existingItem:any) => existingItem[2] === item[2]);

                    if (existingIndex >= 0) {
                      // If the tag exists, update the existing item
                      parsedData[existingIndex] = item;
                      // showAndroidToast("Tag updated successfully.");
                    } else {
                      // If the tag does not exist, add the new item
                      parsedData.push(item);
                      // showAndroidToast("New tag added successfully.");
                    }
                    setTableData(parsedData)
                    // await storeData("tagItems", JSON.stringify(parsedData));
                    setModalVisible2(!modalVisible2); // Close the modal
                    setBatcherVal('')
                    // console.log("Updated Data:", parsedData); // Debug log
                  } catch (error) {
                    console.error("Error updating tagItems:", error);
                    showAndroidToast("Something went wrong, please try again.");
                  }
                }}


                style={{ width: 120, marginLeft: 10, height: 35, backgroundColor: "#192f4b", borderRadius: 3, alignItems: 'center', justifyContent: 'center', alignSelf: 'center' }}>
                <Text style={{ color: 'white' }}>SAVE</Text>
              </TouchableOpacity>
            </View>

          </View>
          {/* <View style={{ height: 0.7, backgroundColor: 'black', width: "90%", alignSelf: 'center' }} /> */}
        </View>
      </Modal>
    </ScrollView>
  );

}
export default Home;


const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, paddingTop: 30, backgroundColor: '#fff' },
  head: { height: 55, backgroundColor: '#ff7075', borderWidth: 0 },
  text1: { margin: 6, color: 'white', fontWeight: '700', fontSize: 16 },
  text2: { margin: 6, color: 'black', fontSize: 14 },
  centeredView: {
    flex: 1,
    alignItems: 'center',
    marginVertical: 10,
    marginHorizontal: 10,
    backgroundColor: 'white',
    borderRadius: 20,
    height: '90%',
    shadowColor: "#000",
    borderColor: "black",
    borderWidth: 1,
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.29,
    shadowRadius: 4.65,
    elevation: 7,
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  buttonOpen: {
    backgroundColor: '#F194FF',
  },
  buttonClose: {
    backgroundColor: '#2196F3',
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'center',
  },
  container2: { flex: 1, padding: 16, paddingTop: 30, backgroundColor: '#fff' },
  header: { height: 50, backgroundColor: '#537791' },
  text: { textAlign: 'center', fontWeight: '100' },
  dataWrapper: { marginTop: -1 },
  row: { height: 40, backgroundColor: '#E7E6E1' }
});


// import React, { useEffect } from 'react';
// import { View, Text, Image, NativeEventEmitter, NativeModules } from 'react-native';
// import { ScrollView } from 'react-native-gesture-handler';
// import { showAndroidToast } from '../utils/Constants';
// import C72RFIDScanner from "uhf-reader-react-native";


// const Home = () => {
//   return (
//     <ScrollView>
//       {isStart&&<Text>scanning</Text>}
//       <View style={{flex:1,backgroundColor:'white'}}>
//       <View style={{backgroundColor:'#ff7076',height:80,justifyContent:'center'}}>
//           <Text style={{fontSize:20,textAlign:'center',color:'white'}}>BATCHER OUT UPDATE</Text>
//       </View>
//       <View>
//         <Image source={require('../../assets/batcher.png')} style={{width:220,height:220, resizeMode:'contain',alignSelf:'center'}} />
//       </View>
//       <View style={{marginHorizontal:20,marginVertical:15}}>
//         <Text style={{fontWeight:"600"}}>Location: <Text style={{fontWeight:"400"}}>Warehouse-1</Text> </Text>
//         <View style={{height:0.5,backgroundColor:'gray',marginTop:19}}></View>
//       </View>
//       <View style={{marginHorizontal:20,marginVertical:15}}>
//         <Text style={{fontWeight:"600"}}>Department: <Text style={{fontWeight:"400"}}>Yarn processing(Spinng)</Text> </Text>
//         <View style={{height:0.5,backgroundColor:'gray',marginTop:19}}></View>
//       </View>
//       <View style={{marginHorizontal:20,marginVertical:15}}>
//         <Text style={{fontWeight:"600"}}>Type: <Text style={{fontWeight:"400"}}>BATCHER</Text> </Text>
//         <View style={{height:0.5,backgroundColor:'gray',marginTop:19}}></View>
//       </View>
//       <View style={{marginHorizontal:20,marginVertical:15}}>
//         <Text style={{fontWeight:"600"}}>Tag: <Text style={{fontWeight:"400"}}>Batcher-1 (2)</Text> </Text>
//         <View style={{height:0.5,backgroundColor:'gray',marginTop:19}}></View>
//       </View>
//       <View style={{marginHorizontal:20,marginVertical:15}}>
//         <Text style={{fontWeight:"600"}}>Status: <Text style={{fontWeight:"400"}}>OUT</Text> </Text>
//         <View style={{height:0.5,backgroundColor:'gray',marginTop:19}}></View>
//       </View>
//       <View style={{marginHorizontal:20,marginVertical:15}}>
//         <Text style={{fontWeight:"600"}}>Date and Time: <Text style={{fontWeight:"400"}}>5 September 2024 06:54:99 PM</Text> </Text>
//         <View style={{height:0.5,backgroundColor:'gray',marginTop:19}}></View>
//       </View>
//     </View>
//     </ScrollView>
//   );
// };

// export default Home;