import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { getTokenSecure, showAndroidToast } from '../utils/Constants';
import { Keyboard } from 'react-native';
import BootSplash from "react-native-bootsplash";
import App from '../../App';
import Home from '../screens/Home';
// import Settings from '../screens/settings/Settings';

const Stack = createNativeStackNavigator();

const ScreenStacks = () => {
    
  return (
    <Stack.Navigator initialRouteName={"Home"}>
      <Stack.Screen
        name="Home"
        component={Home}
        options={{ headerShown: false }}
      /> 
    </Stack.Navigator>
  );
}
export default ScreenStacks;

