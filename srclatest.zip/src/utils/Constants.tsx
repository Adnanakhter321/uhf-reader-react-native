import AsyncStorage from "@react-native-async-storage/async-storage";
import { ToastAndroid } from "react-native";
import * as Keychain from 'react-native-keychain';




export const EncrptPass = "foxit$foxit12";
export const WEBURL = 'http://tos-demo.foxit.pk/';
export const BASEURL = 'http://foxit.cloudex.pk:8041/api';
export const Colors = {
    blue: '#005f84',
    black: '#000000',
    white: "#ffffff",
    gray: '#e5e2e2',
    gray2: '#b7b7b7',
    gray3: '#989898',
    orange: '#fd3f00',
}

export const showAndroidToast = (text: string) => {
    ToastAndroid.show(String(text), ToastAndroid.SHORT);
}

export const storeTokenSecure = async (name: string, token: string) => {
    try {
        return await Keychain.setGenericPassword('authToken', token, {
            service: name, // Optional: Define a custom service name
        });
    } catch (error: any) {
        showAndroidToast(error?.message)
    }
};

export const getTokenSecure = async (name:string) => {
    try {
        const credentials = await Keychain.getGenericPassword({
            service: name, // Optional: Use the same service name
        });
        if (credentials) {
            return credentials?.password;
        } else {
            return null;
        }
    } catch (error: any) {
        showAndroidToast(error?.message)
    }
};

export const deleteTokenSecure = async (name:string) => {
    try {
        await Keychain.resetGenericPassword({
            service: name, // Optional: Use the same service name
        });
    } catch (error: any) {
        showAndroidToast(error?.message)
    }
};



export const storeData = async (key: string, value: any) => {
    try {
        const jsonValue = JSON.stringify(value);
        await AsyncStorage.setItem(key, jsonValue);
    } catch (er: any) {
        ToastAndroid.show(er?.message, ToastAndroid.SHORT);
    }
};

export const getData = async (key: string) => {
    try {
        const jsonValue = await AsyncStorage.getItem(key);
        return jsonValue != null ? JSON.parse(jsonValue) : null;
    } catch (er: string | any) {
        ToastAndroid.show(er?.message, ToastAndroid.SHORT);
    }
};