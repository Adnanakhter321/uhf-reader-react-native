import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import ScreenStacks from './ScreenStacks';
import BootSplash from "react-native-bootsplash";
import { navigationRef } from './NavigationService';


export default function MainStack() {
    return (
        <NavigationContainer ref={navigationRef} 
        // onReady={()=>{
        //     BootSplash.hide();
        // }}
        >
            <ScreenStacks />
        </NavigationContainer>
    );
}