import { createNavigationContainerRef, StackActions } from '@react-navigation/native';

export const navigationRef = createNavigationContainerRef();

// Standard navigation
export const navigate = (name: any, params?: any) => {
  if (navigationRef.isReady()) {
    navigationRef.navigate(name, params);
  }
};

// Go back to the previous screen
export const goBack = () => {
  if (navigationRef.isReady()) {
    navigationRef.goBack();
  }
};

// Reset the stack and navigate to a specific screen
export const resetAndNavigate = (name: string, params?: any) => {
  if (navigationRef.isReady()) {
    navigationRef.reset({
      index: 0,
      routes: [{ name, params }],
    });
  }
};
